import 'package:flutter/material.dart';
import 'dashboard_page.dart'; // Import the dashboard page
import 'service_solution_page.dart'; // Import the solution page

class ServicesPage extends StatelessWidget {
  final List<Map<String, String>> services = [
    {'title': 'Engine Issues', 'image': 'assets/images/reduced.png'},
    {'title': 'Transmission Problems', 'image': 'assets/images/transmission.png'},
    {'title': 'Brake', 'image': 'assets/images/brake.png'},
    {'title': 'Battery Check', 'image': 'assets/images/car-battery.png'},
    {'title': 'Overheating', 'image': 'assets/images/car.png'},
    {'title': 'Shaking Steering Wheel', 'image': 'assets/images/steering-wheel.png'},
    {'title': 'Flat Tires', 'image': 'assets/images/flat-tire.png'},
    {'title': 'Electrical Problems', 'image': 'assets/images/cable-break.png'},
    {'title': 'Warning Light', 'image': 'assets/images/warning-sign.png'},
    {'title': 'Fuel System Issues', 'image': 'assets/images/system.png'},
    {'title': 'Air Conditioning Failures', 'image': 'assets/images/ac.png'},
    {'title': 'Fluid Leaks', 'image': 'assets/images/leaking.png'},
    {'title': 'Malfunctioning Sensors', 'image': 'assets/images/sensor-2.png'},
    {'title': 'Suspension Issues', 'image': 'assets/images/damper.png'},
    {'title': 'Leaking Radiators', 'image': 'assets/images/radiator.png'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Services'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => DashboardPage()),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: Text(
                'How we can assist you',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueAccent,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 15),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1.2,
                ),
                itemCount: services.length,
                itemBuilder: (context, index) {
                  return _buildServiceCard(context, services[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, Map<String, String> service) {
    return InkWell(
      onTap: () async {
        String imagePath = service['image']!;

        print("Navigating to solution page: ${service['title']} with image: $imagePath");

        await precacheImage(AssetImage(imagePath), context);

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ServiceSolutionPage(
              title: service['title']!,
              image: imagePath,
            ),
          ),
        );
      },
      splashColor: Colors.blueAccent.withOpacity(0.3),
      borderRadius: BorderRadius.circular(12),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(service['image']!, height: 50, width: 50),
            SizedBox(height: 8),
            Text(
              service['title']!,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
