import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'profile.dart'; // Import the profile page
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'service_page.dart'; // Import the ServicesPage
import 'chatbot.dart'; // Import the ChatScreen

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final PageController _pageController = PageController();
  late Timer _timer;
  int _currentPage = 0;
  int _selectedIndex = 0; // For bottom navigation
  bool _isProfileIncomplete = false;

  final List<String> imageUrls = [
    'assets/images/269.jpg',
    'assets/images/30006.jpg',
    'assets/images/37298.jpg',
    'assets/images/43025.jpg',
    'assets/images/9886531.jpg',
    'assets/images/11512266.jpg',
    'assets/images/19199270.jpg'
  ];

  @override
  void initState() {
    super.initState();
    _startAutoScroll();
    _checkProfileCompletion();
  }

  @override
  void dispose() {
    _timer.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 2), (Timer timer) {
      if (_currentPage < imageUrls.length - 1) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
    });
  }
  Future<void> _checkProfileCompletion() async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    String uid = auth.currentUser!.uid;

    DocumentSnapshot userDoc = await firestore.collection('users').doc(uid).get();

    if (!userDoc.exists) {
      setState(() {
        _isProfileIncomplete = true;
      });
      return;
    }

    Map<String, dynamic> data = userDoc.data() as Map<String, dynamic>;

    // List of required fields
    List<String> requiredFields = [
      'name', 'phone', 'carName', 'carModel', 'fuelType',
      'transmission', 'carColor', 'vin', 'odoReading'
    ];

    bool hasEmptyFields = requiredFields.any((field) =>
    data[field] == null || (data[field] as String).trim().isEmpty);

    setState(() {
      _isProfileIncomplete = hasEmptyFields;
    });
  }

  Future<String> _getCarDetails() async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    String uid = auth.currentUser!.uid;

    DocumentSnapshot userDoc = await firestore.collection('users')
        .doc(uid)
        .get();

    if (!userDoc.exists) {
      return "User details not found.";
    }

    Map<String, dynamic> data = userDoc.data() as Map<String, dynamic>;

    String name = data['name'] ?? 'N/A';
    String phone = data['phone'] ?? 'N/A';
    String carName = data['carName'] ?? 'N/A';
    String carModel = data['carModel'] ?? 'N/A';
    String fuelType = data['fuelType'] ?? 'N/A';
    String transmission = data['transmission'] ?? 'N/A';
    String carColor = data['carColor'] ?? 'N/A';
    String vin = data['vin'] ?? 'N/A';
    String odoReading = data['odoReading'] ?? 'N/A';

    return """
🚗 *Car Details Inquiry*
👤 Name: $name
📞 Phone: $phone
🚘 Car Name: $carName
📅 Model: $carModel
⛽ Fuel Type: $fuelType
⚙️ Transmission: $transmission
🎨 Color: $carColor
🔢 VIN: $vin
📏 Odometer Reading: $odoReading

I need assistance with spare parts. Please help! 🔧
""";
  }


  void _onItemTapped(int index) {
    if (index == _selectedIndex) return;

    setState(() {
      _selectedIndex = index;
    });

    if (index == 0) {
      // Dashboard (Already on this page)
    } else if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => ServicesPage()),
      );
    } else if (index == 2) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => ProfilePage()), // Navigate to Profile
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        backgroundColor: Colors.blueAccent,

      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: 200,
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: imageUrls.length,
                  onPageChanged: (index) {
                    _currentPage = index;
                  },
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8.0),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(imageUrls[index]),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 10,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              SmoothPageIndicator(
                controller: _pageController,
                count: imageUrls.length,
                effect: const ExpandingDotsEffect(
                  dotHeight: 8,
                  dotWidth: 8,
                  activeDotColor: Colors.blueAccent,
                ),
              ),
              const SizedBox(height: 24),
              _buildInfoCard(
                icon: Icons.car_repair,
                title: "Car Service Assistant App",
                content:
                "Your all-in-one solution for car maintenance, troubleshooting, and repairs.",
              ),
              _buildInfoCard(
                icon: Icons.smart_toy,
                title: "Meet 'Road Buddy' – Your AI Car Assistant!",
                content:
                "Need help with a car issue? 'Road Buddy' provides troubleshooting steps, diagnostic insights, and possible repair solutions.",
              ),
              _buildContactCard(), // Contact Card
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: [
          const BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Dashboard",
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.build),
            label: "Services",
          ),
          BottomNavigationBarItem(
            icon: Stack(
              clipBehavior: Clip.none, // Allows positioning outside the normal bounds
              children: [
                const Icon(Icons.account_circle, size: 30), // Profile Icon
                if (_isProfileIncomplete) // Show warning icon if profile is incomplete
                  Positioned(
                    right: -3, // Adjust position near the profile icon
                    top: -3,
                    child: Icon(Icons.error, color: Colors.red, size: 16), // ❗ Warning Symbol
                  ),
              ],
            ),
            label: "Profile",
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ChatBotScreen()), // Navigate to ChatScreen
          );
        },
        backgroundColor: Colors.blueAccent,
        child: const FaIcon(
            FontAwesomeIcons.robot, size: 28, color: Colors.white),
      ),
    );
  }


  Widget _buildContactCard() {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.phone, color: Colors.blueAccent, size: 28),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    "Need Spare Parts? Contact Us!",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildContactButton(
                  icon: FontAwesomeIcons.whatsapp,
                  label: "WhatsApp",
                  color: Colors.green,
                  onTap: _openWhatsApp,
                ),
                _buildContactButton(
                  icon: Icons.email,
                  label: "Email",
                  color: Colors.blueAccent,
                  onTap: _sendEmail,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color, width: 1.5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String content,
    VoidCallback? onTap, // Optional action for the card
  }) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: Colors.blueAccent, size: 30),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                content,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 12),
              if (onTap != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: onTap,
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white, backgroundColor: Colors.blueAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Learn More'),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }



  void _contactOptionsDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Contact Us"),
          content: const Text("How would you like to reach us?"),
          actions: [
            TextButton.icon(
              onPressed: _openWhatsApp,
              icon: const FaIcon(
                  FontAwesomeIcons.whatsapp, color: Colors.green),
              label: const Text("WhatsApp"),
            ),
            TextButton.icon(
              onPressed: _sendEmail,
              icon: const Icon(Icons.email, color: Colors.blue),
              label: const Text("Email"),
            ),
          ],
        );
      },
    );
  }


  void _openWhatsApp() async {
    String phoneNumber = "7025661621"; // Your business WhatsApp number
    String message = await _getCarDetails(); // Fetch user car details

    final Uri url = Uri.parse(
        "https://wa.me/$phoneNumber?text=${Uri.encodeComponent(message)}");

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void _sendEmail() async {
    String email = "ffixandgo@gmail.com"; // Your email
    String subject = "Spare Parts Inquiry";
    String body = await _getCarDetails(); // Fetch user car details

    final Uri emailUrl = Uri.parse(
        "mailto:$email?subject=${Uri.encodeComponent(subject)}&body=${Uri
            .encodeComponent(body)}");

    if (await canLaunchUrl(emailUrl)) {
      await launchUrl(emailUrl);
    }
  }

}