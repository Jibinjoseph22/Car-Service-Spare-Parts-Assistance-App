import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';

class ChatBotScreen extends StatefulWidget {
  @override
  _ChatBotScreenState createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, String>> _messages = [];
  final String apiKey = "AIzaSyA2eSYOZ4mzRbqDJzMMTZ7ZScxDl-iSygQ"; // Replace with your API key
  bool isLoading = false;
  String typingText = "Typing";
  Timer? typingTimer;

  @override
  void initState() {
    super.initState();
    _messages.add({"bot": "Hi! How can I assist you with your vehicle today?"});
  }

  Future<String> getBotResponse(String query) async {
    final url = Uri.parse(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey");

    List<String> conversationHistory = _messages
        .take(_messages.length > 5 ? 5 : _messages.length)
        .map((msg) => msg.containsKey("user")
        ? "User: ${msg["user"]}"
        : "Bot: ${msg["bot"]}")
        .toList();

    String prompt = """
You are an AI chatbot specialized in **Car Service and Repair Assistance**. You should:
- **Respond only to vehicle-related questions** (maintenance, repairs, parts, insurance, troubleshooting, etc.).
- **Use past messages to stay context-aware** and ask for more details if needed.
- If the user asks something unrelated to cars, **politely ignore it**.
- Be **direct, informative, and friendly**.

Recent Conversation:
${conversationHistory.join("\n")}

User's new message: "$query"
""";

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": prompt}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        String botReply = jsonResponse['candidates']?[0]['content']?['parts']?[0]['text'] ??
            "I'm sorry, I couldn't process that request.";

        return botReply.replaceAll('*', '').replaceAll('\\n', '\n');
      } else {
        return "Error: ${response.statusCode} - ${response.body}";
      }
    } catch (e) {
      return "Network Error: $e";
    }
  }

  void sendMessage() async {
    String message = _controller.text.trim();
    if (message.isEmpty) return;

    setState(() {
      _messages.add({"user": message});
      _controller.clear();
      isLoading = true;
      _messages.add({"bot": "Typing"});
      _startTypingAnimation();
    });

    _scrollToBottom();

    String botReply = await getBotResponse(message);

    setState(() {
      _messages.removeLast();
      _messages.add({"bot": botReply});
      isLoading = false;
    });

    _stopTypingAnimation();
    _scrollToBottom();

    FirebaseFirestore.instance.collection('chats').add({
      "userMessage": message,
      "botResponse": botReply,
      "timestamp": DateTime.now(),
    });
  }

  void _scrollToBottom() {
    Future.delayed(Duration(milliseconds: 300), () {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  void _startTypingAnimation() {
    typingTimer = Timer.periodic(Duration(milliseconds: 500), (timer) {
      setState(() {
        typingText = typingText == "Typing..." ? "Typing" : "$typingText.";
      });
    });
  }

  void _stopTypingAnimation() {
    typingTimer?.cancel();
    typingTimer = null;
  }

  @override
  void dispose() {
    _stopTypingAnimation();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Car Service Chatbot"), backgroundColor: Colors.blueAccent),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                bool isUser = msg.containsKey("user");

                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.blue[300] : Colors.grey[300],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(msg.values.first, style: TextStyle(fontSize: 16)),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _controller, decoration: InputDecoration(hintText: "Type your message...", border: OutlineInputBorder()))),
                IconButton(icon: Icon(Icons.send, color: Colors.blue), onPressed: sendMessage),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
