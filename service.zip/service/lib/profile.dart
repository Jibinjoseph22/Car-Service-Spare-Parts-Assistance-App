import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'dashboard_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final _formKey = GlobalKey<FormState>();

  String? _name, _phone, _address, _carName, _carModel, _fuelType, _transmission, _carColor, _vin, _odoReading;
  late String _userEmail;
  bool _isLoading = true;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _carNameController = TextEditingController();
  final TextEditingController _carModelController = TextEditingController();
  final TextEditingController _fuelTypeController = TextEditingController();
  final TextEditingController _transmissionController = TextEditingController();
  final TextEditingController _carColorController = TextEditingController();
  final TextEditingController _vinController = TextEditingController();
  final TextEditingController _odoReadingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _userEmail = _auth.currentUser?.email ?? '';
    _fetchUserData();
  }

  // Fetch user data from Firestore
  Future<void> _fetchUserData() async {
    final doc = await _firestore.collection('users').doc(_auth.currentUser!.uid).get();
    if (doc.exists) {
      setState(() {
        _nameController.text = doc['name'] ?? '';
        _phoneController.text = doc['phone'] ?? '';
        _addressController.text = doc['address'] ?? '';
        _carNameController.text = doc['carName'] ?? '';
        _carModelController.text = doc['carModel'] ?? '';
        _fuelTypeController.text = doc['fuelType'] ?? '';
        _transmissionController.text = doc['transmission'] ?? '';
        _carColorController.text = doc['carColor'] ?? '';
        _vinController.text = doc['vin'] ?? '';
        _odoReadingController.text = doc['odoReading'] ?? '';
      });
    }
    setState(() {
      _isLoading = false;
    });
  }

  // Save profile information to Firestore
  Future<void> _saveProfile() async {
    if (_formKey.currentState!.validate()) {
      try {
        await _firestore.collection('users').doc(_auth.currentUser!.uid).set({
          'name': _nameController.text,
          'phone': _phoneController.text,
          'address': _addressController.text,
          'carName': _carNameController.text,
          'carModel': _carModelController.text,
          'fuelType': _fuelTypeController.text,
          'transmission': _transmissionController.text,
          'carColor': _carColorController.text,
          'vin': _vinController.text,
          'odoReading': _odoReadingController.text,
          'email': _userEmail,
        }, SetOptions(merge: true));

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving profile: $e')),
        );
      }
    }
  }

  // Logout function
  Future<void> _logout() async {
    await _auth.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.blueAccent,
        leading: IconButton(  // Back button added here
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => DashboardPage()),
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),

      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Profile Picture Section
              Center(
                child: CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.grey[200],
                  child: const Icon(Icons.person, size: 60, color: Colors.blueAccent),
                ),
              ),
              const SizedBox(height: 20),

              // User Info Section
              _buildSectionTitle('User Information'),
              _buildProfileInfoRow('Email', _userEmail),
              _buildTextField('Name', _nameController),
              _buildTextField('Phone', _phoneController),
              _buildTextField('Address', _addressController),

              const SizedBox(height: 20),

              // Car Information Section
              _buildSectionTitle('Car Information'),
              _buildTextField('Car Name', _carNameController),
              _buildTextField('Car Model', _carModelController),
              _buildTextField('Fuel Type', _fuelTypeController),
              _buildTextField('Transmission', _transmissionController),
              _buildTextField('Car Color', _carColorController),
              _buildTextField('VIN', _vinController),
              _buildTextField('Odometer Reading', _odoReadingController),

              const SizedBox(height: 20),

              // Save Profile Button
              ElevatedButton(
                onPressed: _saveProfile,
                child: const Text('Save Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget to display a section title
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.blueAccent,
        ),
      ),
    );
  }

  // Widget to display a row with label and data
  Widget _buildProfileInfoRow(String label, String data) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            data,
            style: const TextStyle(fontSize: 16, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  // Widget to create a text field for input
  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.blueAccent),
          filled: true,
          fillColor: Colors.grey[200],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        validator: (value) => value!.isEmpty ? 'Please enter $label' : null,
      ),
    );
  }
}
