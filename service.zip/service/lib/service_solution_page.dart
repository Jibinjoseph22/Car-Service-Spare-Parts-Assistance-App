import 'package:flutter/material.dart';

class ServiceSolutionPage extends StatelessWidget {
  final String title;
  final String image;

  ServiceSolutionPage({required this.title, required this.image});

  @override
  Widget build(BuildContext context) {
    String solutionText = getSolution(title);

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Image.asset(image, height: 120)),
            const SizedBox(height: 20),
            Text(
              'Solution for $title',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              solutionText,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  String getSolution(String title) {
    switch (title) {
      case 'Engine Issues':
        return '''
Common Causes:
1. Low or Dirty Engine Oil
	•	Effect: Inadequate lubrication causes excessive friction, overheating, and wear on engine components.
	•	Signs: Knocking noises, burning smell, or oil warning light on the dashboard.

2. Faulty Spark Plugs or Ignition Coils
	•	Effect: Poor combustion leads to misfires, rough idling, and difficulty starting the car.
	•	Signs: Check engine light, power loss, rough engine sound.

3. Fuel Delivery Problems
	•	Effect: The engine won’t get the correct fuel mixture, causing hesitation, stalling, or non-starting conditions.
	•	Signs: Engine sputtering, poor fuel efficiency, difficulty starting the car.

4. Overheating Engine
	•	Effect: High temperatures damage engine components and can cause a blown head gasket.
	•	Signs: Temperature gauge in the red zone, steam from the hood.

5. Sensor Malfunctions (Oxygen Sensor, Mass Air Flow Sensor, etc.)
	•	Effect: Incorrect air-fuel mixture leads to inefficient combustion and performance issues.
	•	Signs: Check engine light, poor acceleration, excessive emissions.

6. Exhaust System Blockages or Leaks
	•	Effect: Back pressure builds up, reducing power and efficiency.
	•	Signs: Loud exhaust noise, loss of power, increased fuel consumption.

Solutions:
1️⃣ Check and Change Engine Oil

✅ How to Fix:
	•	Open the hood and locate the oil dipstick.
	•	Pull it out, wipe it clean, and reinsert it to check the oil level.
	•	If low, add the correct grade of oil recommended by the manufacturer.
	•	If the oil looks black and dirty, change it along with the oil filter.

🛠️ When to Seek Help? If you notice metal shavings in the oil, get a mechanic to inspect for internal engine wear.

1️⃣ Check and Change Engine Oil

✅ How to Fix:
	•	Open the hood and locate the oil dipstick.
	•	Pull it out, wipe it clean, and reinsert it to check the oil level.
	•	If low, add the correct grade of oil recommended by the manufacturer.
	•	If the oil looks black and dirty, change it along with the oil filter.

🛠️ When to Seek Help? If you notice metal shavings in the oil, get a mechanic to inspect for internal engine wear.

3️⃣ Check the Fuel System (Fuel Pump, Filter, Injectors)

✅ How to Fix:
	•	Turn the key to “ON” (without starting) and listen for a fuel pump whirring sound. If silent, the pump may be faulty.
	•	Replace a clogged fuel filter to ensure proper fuel flow.
	•	Use a fuel injector cleaner to remove carbon buildup.

🛠️ When to Seek Help? If the fuel pump is faulty, it needs mechanic replacement.

4️⃣ Address Overheating Issues

✅ How to Fix:
	•	Check coolant levels and radiator cap (only when the engine is cool).
	•	Inspect for leaks in the radiator, hoses, or water pump.
	•	Ensure the radiator fan is spinning when the engine gets hot.
	•	If overheating persists, check the thermostat (a stuck thermostat can cause overheating).

🛠️ When to Seek Help? If overheating continues despite coolant refills, the head gasket may be blown.

5️⃣ Scan for Faulty Sensors (Oxygen Sensor, MAF Sensor, etc.)

✅ How to Fix:
	•	Use an OBD-II scanner to check for engine trouble codes.
	•	Clean or replace the Mass Air Flow (MAF) sensor if dirty.
	•	Replace the Oxygen (O2) sensor if fuel efficiency is poor.

🛠️ When to Seek Help? If multiple sensors fail, there might be a wiring or ECM issue.

6️⃣ Inspect the Exhaust System for Blockages

✅ How to Fix:
	•	Check for exhaust leaks near the manifold (listen for loud hissing sounds).
	•	Remove carbon buildup in the exhaust pipe using a cleaner.
	•	If the catalytic converter is clogged, replace it.

🛠️ When to Seek Help? A completely blocked exhaust requires mechanic intervention.

🚀 Preventive Maintenance Tips to Avoid Engine Issues

✅ Check Engine Oil Every 5,000 Miles
✅ Replace Spark Plugs Every 30,000 Miles
✅ Use High-Quality Fuel to avoid injector clogging
✅ Monitor Coolant Levels Regularly
✅ Scan for Check Engine Codes Using an OBD-II Scanner
''';

      case 'Transmission Problems':
        return '''
Common Symptoms:
1. Low or Contaminated Transmission Fluid
	•	Effect: Insufficient lubrication causes overheating and poor gear shifting.
	•	Signs: Delayed shifting, slipping gears, burning smell, transmission overheating.

2. Worn-Out Clutch (Manual & Automatic Transmissions)
	•	Effect: The clutch fails to engage or disengage properly, leading to slipping gears.
	•	Signs: Grinding noise, difficulty changing gears, sudden loss of acceleration.

3. Faulty Transmission Solenoid
	•	Effect: The solenoid controls the flow of fluid in the transmission. A malfunction leads to irregular shifting.
	•	Signs: Gear slipping, delays in gear shifting, stuck in one gear.

4. Transmission Overheating
	•	Effect: High temperatures cause fluid breakdown and internal damage.
	•	Signs: Burning smell, erratic shifting, transmission warning light on dashboard.

5. Torque Converter Issues
	•	Effect: Poor power transmission from the engine to the transmission results in shaking or shuddering.
	•	Signs: Vibration when driving, difficulty accelerating, slipping gears.

6. Broken or Worn Transmission Bands
	•	Effect: Transmission bands help engage gears. If worn out, shifting becomes rough or impossible.
	•	Signs: Slipping gears, high engine RPMs with no acceleration.

7. Software or Electronic Control Issues
	•	Effect: Modern vehicles rely on transmission control modules (TCMs). Software glitches can cause erratic shifting.
	•	Signs: Unpredictable gear shifts, check engine light, transmission stuck in limp mode.1️⃣ Check and Change Transmission Fluid

✅ How to Fix:
	•	Locate the transmission dipstick (usually near the engine bay).
	•	Pull it out, wipe clean, and reinsert to check the level.
	•	If fluid is low, add manufacturer-recommended ATF (Automatic Transmission Fluid).
	•	If the fluid is dark, burnt-smelling, or has debris, drain and replace it.

🛠️ When to Seek Help? If the fluid smells burnt or has metal shavings, internal components might be wearing out.

2️⃣ Inspect & Replace the Clutch (For Manual & Automatic Transmissions)

✅ How to Fix:
	•	Manual Transmission:
	•	If the clutch pedal feels too soft or hard, inspect the clutch cable or hydraulic system.
	•	Replace worn-out clutch plates or adjust the clutch cable tension.
	•	Automatic Transmission:
	•	If the car jerks when shifting, it could be due to a worn-out torque converter clutch.
	•	A mechanic should inspect and replace the torque converter if needed.

🛠️ When to Seek Help? If the clutch is slipping despite adjustments, a full clutch replacement may be necessary.

3️⃣ Test and Replace a Faulty Transmission Solenoid

✅ How to Fix:
	•	Use an OBD-II scanner to check for error codes related to the transmission solenoid.
	•	If faulty, locate the solenoid pack (inside the transmission pan) and replace it.
	•	Ensure the transmission fluid is clean and at the right level after replacement.

🛠️ When to Seek Help? If replacing the solenoid doesn’t fix shifting problems, the transmission valve body may need professional servicing.

4️⃣ Prevent Overheating in the Transmission

✅ How to Fix:
	•	Check coolant levels regularly, as the radiator helps cool the transmission fluid.
	•	Ensure transmission fluid is clean and full to prevent overheating.
	•	If the vehicle tows heavy loads, consider installing a transmission cooler.

🛠️ When to Seek Help? If the transmission continues to overheat, internal components may be failing.

5️⃣ Diagnose Torque Converter Issues

✅ How to Fix:
	•	If you feel shuddering or vibrations, add torque converter additive to smooth out operation.
	•	If the problem persists, the torque converter clutch may need replacing.

🛠️ When to Seek Help? If vibrations get worse, a mechanic should inspect the torque converter and transmission pump.

6️⃣ Repair or Replace Worn Transmission Bands

✅ How to Fix:
	•	Transmission bands can sometimes be adjusted to restore shifting ability.
	•	If they are worn out, they need to be replaced by a mechanic.

🛠️ When to Seek Help? If adjusting the bands doesn’t resolve gear slippage, a transmission rebuild may be necessary.

7️⃣ Reset or Reprogram the Transmission Control Module (TCM)

✅ How to Fix:
	•	Disconnect the car battery for 10–15 minutes to reset the transmission software.
	•	If problems persist, use an OBD-II scanner to update the Transmission Control Module (TCM) firmware.
	•	In some cases, a dealership reflash of the TCM software is required.

🛠️ When to Seek Help? If transmission remains stuck in limp mode or shifts erratically, seek professional reprogramming.

🚀 Preventive Maintenance Tips for a Healthy Transmission

✅ Check & Change Transmission Fluid Every 30,000-60,000 Miles
✅ Avoid Sudden Acceleration or Hard Braking to reduce transmission strain
✅ Allow the Engine to Warm Up Before Driving in cold weather
✅ Don’t Overload the Vehicle beyond its recommended weight capacity
✅ Use a Transmission Cooler if frequently towing heavy loads

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ The transmission fails to shift gears completely
❌ The check engine or transmission warning light is on
❌ The vehicle gets stuck in one gear or limp mode
❌ Fluid leaks persist despite refilling
''';

      case 'Brake Issues':
        return '''
**Common Symptoms:**
1. Worn-Out Brake Pads
	•	Effect: Reduced braking efficiency, longer stopping distances, and possible damage to the brake rotor.
	•	Signs: Squeaking or grinding noise, vibration in the pedal, slow braking response.

2. Brake Fluid Leak (Hydraulic Failure)
	•	Effect: A loss of brake fluid leads to a spongy pedal or total brake failure.
	•	Signs: Brake warning light, fluid puddles under the car (yellowish or brown fluid).

3. Air in the Brake Lines
	•	Effect: Air bubbles reduce hydraulic pressure, leading to a soft or spongy brake pedal.
	•	Signs: Soft brake pedal, inconsistent braking power, pedal goes to the floor.

4. Warped Brake Rotors
	•	Effect: Uneven braking and excessive vibration when applying brakes.
	•	Signs: Steering wheel shaking, vibrations when braking at high speeds.

5. Stuck Brake Calipers
	•	Effect: One or more brakes remain engaged, causing uneven braking or pulling to one side.
	•	Signs: Car pulls to one side, overheating brakes, uneven pad wear.

6. ABS (Anti-Lock Brake System) Malfunction
	•	Effect: Loss of ABS assistance can cause skidding on slippery surfaces.
	•	Signs: ABS warning light on, brakes locking up in emergency stops.

7. Brake Master Cylinder Failure
	•	Effect: Brake pressure drops, leading to a weak or ineffective braking system.
	•	Signs: Pedal sinks to the floor, brake warning light, inconsistent braking.

Solutions:
1️⃣ Check and Replace Worn-Out Brake Pads

✅ How to Fix:
	•	Remove the wheel to inspect brake pad thickness. If it’s less than 3mm, replace them.
	•	Listen for squeaking or grinding noises—these indicate metal-on-metal contact.
	•	Use OEM brake pads for better durability and braking efficiency.

🛠️ When to Seek Help? If the pads are worn out, replace them immediately to avoid damaging the rotors.

2️⃣ Inspect for Brake Fluid Leaks and Refill the Reservoir

✅ How to Fix:
	•	Locate the brake fluid reservoir under the hood and check the fluid level.
	•	If the fluid is low, refill with DOT-approved brake fluid (DOT 3, DOT 4, or DOT 5.1).
	•	Check for leaks near the master cylinder, brake lines, and calipers.

🛠️ When to Seek Help? If leaks persist, a mechanic must repair or replace the brake lines.

3️⃣ Bleed the Brake Lines to Remove Air Bubbles

✅ How to Fix:
	•	Two-person method: One person pumps the brake pedal while the other releases air from the bleed valve.
	•	Use a vacuum pump to remove air if doing it solo.
	•	Always start bleeding from the farthest wheel (rear right) and move closer to the master cylinder.

🛠️ When to Seek Help? If the brakes remain spongy after bleeding, there may be a deeper hydraulic issue.

4️⃣ Resurface or Replace Warped Brake Rotors

✅ How to Fix:
	•	If rotors are mildly warped, they can be resurfaced by a mechanic.
	•	If severely warped, replace them to ensure even braking performance.
	•	Use high-quality vented rotors for better heat dissipation.

🛠️ When to Seek Help? If vibrations persist after resurfacing, replace both brake rotors and pads.

5️⃣ Fix Stuck Brake Calipers

✅ How to Fix:
	•	Inspect the caliper pistons for rust or dirt buildup.
	•	Lubricate caliper slide pins to allow smooth movement.
	•	If the caliper is stuck permanently, replace it.

🛠️ When to Seek Help? If one brake pad is worn more than the other, the caliper is likely sticking and needs replacing.

6️⃣ Diagnose and Repair ABS (Anti-Lock Brake System) Issues

✅ How to Fix:
	•	Check for ABS warning lights and scan the car using an OBD-II scanner.
	•	Inspect the wheel speed sensors—clean or replace if faulty.
	•	Ensure the ABS fuse is intact; replace if blown.

🛠️ When to Seek Help? If the ABS warning light remains on, the ABS module or pump may need professional repair.

7️⃣ Replace a Faulty Brake Master Cylinder

✅ How to Fix:
	•	If the pedal sinks to the floor, the master cylinder seals may be leaking.
	•	Inspect for fluid leaks near the master cylinder and check if the brake fluid is dark.
	•	Replace the master cylinder and bleed the brakes properly after installation.

🛠️ When to Seek Help? If the brakes fail completely, seek immediate mechanical assistance.

🚀 Preventive Maintenance Tips for a Healthy Brake System

✅ Check Brake Pads Every 10,000 Miles (replace at 3mm or below)
✅ Flush Brake Fluid Every 2 Years to remove contaminants
✅ Avoid Hard Braking unless necessary to reduce wear
✅ Inspect Brake Lines & Calipers Annually
✅ Use Quality Brake Components for better performance

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ Brakes make grinding noises or don’t respond quickly
❌ The brake pedal sinks or feels too soft
❌ The ABS warning light stays on
❌ You notice fluid leaks under the car

''';

      case 'Battery Check':
        return '''
Common Symptoms:
🔍 Common Causes of Battery Problems

1️⃣ Dead or Weak Battery
	•	Effect: Car won’t start or struggles to crank.
	•	Signs: Dim headlights, slow engine crank, clicking sound when turning the key.

2️⃣ Corroded Battery Terminals
	•	Effect: Poor electrical connection, weak battery charge.
	•	Signs: White, green, or blue powdery deposits on battery terminals, trouble starting the car.

3️⃣ Faulty Alternator
	•	Effect: Battery does not charge properly while driving.
	•	Signs: Battery warning light on the dashboard, dimming lights, frequent battery failure.

4️⃣ Parasitic Battery Drain
	•	Effect: Battery drains overnight or while parked.
	•	Signs: Car won’t start after sitting for a while, power loss even with a new battery.

5️⃣ Loose or Damaged Battery Cables
	•	Effect: Intermittent power loss, weak electrical connections.
	•	Signs: Car randomly stalls, loss of electrical functions, flickering dashboard lights.

6️⃣ Extreme Weather Conditions
	•	Effect: Reduced battery performance in extreme cold or heat.
	•	Signs: Hard starting in winter, battery swelling in summer.

7️⃣ Old Battery (Beyond Lifespan)
	•	Effect: Battery loses its ability to hold a charge over time.
	•	Signs: Battery older than 3-5 years, frequent jump-starts needed.

Solutions:
🛠️ Step-by-Step Solutions for Battery Problems

1️⃣ Test and Replace a Weak Battery

✅ How to Fix:
	•	Use a voltmeter to test the battery voltage:
	•	12.6V or more = Battery is fully charged
	•	12.4V = Battery is low, needs recharging
	•	Below 12.0V = Weak battery, may need replacement
	•	If the battery is older than 3-5 years, replace it.

🛠️ When to Seek Help? If the car doesn’t start even after charging the battery.

2️⃣ Clean Corroded Battery Terminals

✅ How to Fix:
	•	Disconnect the negative (-) terminal first, then the positive (+).
	•	Use baking soda and water to clean corrosion. Scrub with a brush.
	•	Apply petroleum jelly or battery terminal grease to prevent future corrosion.

🛠️ When to Seek Help? If corrosion reappears quickly, there may be a battery leak.

3️⃣ Check the Alternator for Charging Issues

✅ How to Fix:
	•	Start the car and measure battery voltage:
	•	13.8V - 14.5V = Alternator is charging properly
	•	Less than 13.0V = Alternator may be failing
	•	If the alternator is bad, replace it.

🛠️ When to Seek Help? If dashboard lights flicker, or the battery drains quickly while driving.

4️⃣ Find and Fix Parasitic Battery Drain

✅ How to Fix:
	•	Use a multimeter to check for current draw when the car is off.
	•	Remove fuses one by one to find the faulty circuit.
	•	Common causes: Glove box light, faulty relay, aftermarket accessories.

🛠️ When to Seek Help? If you can’t identify the source of battery drain.

5️⃣ Secure Loose Battery Cables and Terminals

✅ How to Fix:
	•	Check battery cable connections and tighten if loose.
	•	Replace damaged or frayed cables.

🛠️ When to Seek Help? If the car stalls even after securing the cables.

6️⃣ Protect Battery from Extreme Weather

✅ How to Fix:
	•	In cold weather, use a battery warmer or insulation blanket.
	•	In hot weather, park in the shade and keep the battery topped up.

🛠️ When to Seek Help? If extreme temperatures repeatedly drain your battery.

7️⃣ Replace an Old Battery

✅ How to Fix:
	•	If your battery is older than 3-5 years, replace it.
	•	Choose a high-quality battery with the right cold cranking amps (CCA).

🛠️ When to Seek Help? If the battery dies quickly even after a full charge.

🚀 Preventive Maintenance Tips for a Healthy Battery

✅ Check Battery Voltage Monthly with a voltmeter.
✅ Clean Terminals Every 6 Months to prevent corrosion.
✅ Turn Off Accessories when the car is off (radio, lights, AC).
✅ Drive Regularly to keep the battery charged.
✅ Test Alternator Annually to avoid charging issues.

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ The car doesn’t start even after a jump-start.
❌ Battery keeps dying overnight.
❌ Alternator warning light is on.
❌ There’s a burning smell or visible battery damage.

''';

      case 'Overheating':
        return '''
Common Causes:
🔍 Common Causes of Overheating

1️⃣ Low or Leaking Coolant (Antifreeze)
	•	Effect: The engine doesn’t get enough cooling, causing overheating.
	•	Signs: Low coolant levels, puddles under the car, warning light on the dashboard.

2️⃣ Faulty Radiator or Clogged Cooling System
	•	Effect: The radiator fails to dissipate heat properly.
	•	Signs: Visible rust in the radiator, coolant leaks, hot engine.

3️⃣ Broken or Malfunctioning Thermostat
	•	Effect: Coolant doesn’t circulate properly, causing excessive heat.
	•	Signs: Temperature fluctuates rapidly, engine overheats after a few minutes.

4️⃣ Failing Water Pump
	•	Effect: Coolant doesn’t flow through the engine efficiently.
	•	Signs: High engine temperature, leaks near the front of the engine, whining noises.

5️⃣ Cooling Fan Not Working
	•	Effect: Heat isn’t removed efficiently from the engine.
	•	Signs: Fan doesn’t turn on when the engine is hot, overheating in traffic.

6️⃣ Blocked or Leaking Hoses
	•	Effect: Coolant doesn’t circulate properly, causing engine temperature to rise.
	•	Signs: Bulging hoses, visible coolant leaks, overheating even with coolant topped up.

7️⃣ Engine Oil is Too Low or Dirty
	•	Effect: Lack of lubrication increases friction and heat in the engine.
	•	Signs: Low oil level, dark or dirty oil, burning smell.

Solutions:
🛠️ Step-by-Step Solutions for Overheating Issues

1️⃣ Check and Refill Coolant

✅ How to Fix:
	•	Wait until the engine cools down before opening the radiator cap.
	•	Refill with the correct coolant type for your car.
	•	If coolant is consistently low, check for leaks.

🛠️ When to Seek Help? If the coolant keeps disappearing, it could indicate a radiator or head gasket leak.

2️⃣ Inspect the Radiator for Leaks or Clogs

✅ How to Fix:
	•	Check for coolant leaks around the radiator.
	•	Look inside the radiator for rust or debris.
	•	Flush the radiator every 30,000 miles to remove buildup.

🛠️ When to Seek Help? If the radiator is leaking, it may need to be replaced.

3️⃣ Test the Thermostat for Proper Functioning

✅ How to Fix:
	•	Start the car and feel the upper radiator hose after a few minutes.
	•	If the hose stays cold, the thermostat is stuck closed and should be replaced.
	•	If the hose gets hot too quickly, the thermostat might be stuck open, causing poor cooling.

🛠️ When to Seek Help? If the car overheats within minutes of starting, replace the thermostat.

4️⃣ Check the Water Pump for Wear or Leaks

✅ How to Fix:
	•	Look for coolant leaks near the water pump.
	•	Listen for squealing or grinding noises from the pump.
	•	Replace the water pump if it shows signs of failure.

🛠️ When to Seek Help? If the water pump is failing, it must be replaced to avoid serious engine damage.

5️⃣ Inspect and Fix the Cooling Fan

✅ How to Fix:
	•	Turn on the AC—if the cooling fan doesn’t start, check the fan motor or relay.
	•	Replace a faulty fan motor or repair electrical issues.

🛠️ When to Seek Help? If the fan isn’t running at all, it could be an electrical issue or a bad relay.

6️⃣ Check Hoses for Leaks and Blockages

✅ How to Fix:
	•	Inspect hoses for cracks, bulges, or leaks.
	•	If hoses are hard or collapsed, replace them.
	•	Ensure hoses are properly connected.

🛠️ When to Seek Help? If the hoses are swollen or leaking, replace them immediately.

7️⃣ Change or Top Up Engine Oil

✅ How to Fix:
	•	Check the oil dipstick—if the oil is low or dark, change it.
	•	Use the correct oil type for your car.
	•	Change oil every 5,000 - 7,500 miles.

🛠️ When to Seek Help? If the oil has a milky appearance, it could mean a blown head gasket, which needs immediate attention.

🚨 What to Do If Your Car Overheats While Driving?

1️⃣ Turn Off the AC & Turn On the Heater – This pulls heat away from the engine.
2️⃣ Pull Over and Turn Off the Engine – Allow the car to cool down.
3️⃣ Check Coolant Levels – If low, top up with coolant or water temporarily.
4️⃣ Look for Leaks Under the Car – Check for coolant puddles.
5️⃣ Don’t Open the Radiator Cap Immediately – Wait until the engine is completely cool.
6️⃣ Call for Assistance – If the issue persists, seek professional help.

🚀 Preventive Maintenance Tips for Avoiding Overheating

✅ Check Coolant Levels Regularly (every month).
✅ Flush the Radiator every 30,000 miles.
✅ Replace the Thermostat if overheating persists.
✅ Inspect the Cooling Fan & Belts annually.
✅ Check for Leaks & Fix Them Immediately.

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ The car continues to overheat even with coolant.
❌ You notice white smoke from the exhaust (could indicate a blown head gasket).
❌ The radiator is leaking significantly.
❌ The temperature gauge stays in the red zone.
''';

      case 'Flat Tires':
        return '''
Common Causes:
🔍 Common Causes of Flat Tires

1️⃣ Punctures from Sharp Objects (Nails, Glass, Screws)
	•	Effect: The tire slowly or quickly loses air, depending on the size of the puncture.
	•	Signs: A visible object stuck in the tire, a slow air leak, or a sudden tire blowout.

2️⃣ Underinflated Tires
	•	Effect: Low air pressure increases friction, causing overheating and premature tire wear.
	•	Signs: Soft or squishy tires, the TPMS (Tire Pressure Monitoring System) warning light.

3️⃣ Overinflated Tires
	•	Effect: Excessive pressure makes the tire stiff and prone to bursting when hitting potholes.
	•	Signs: Uneven tire wear, rough ride quality, sudden blowouts.

4️⃣ Worn-Out or Old Tires
	•	Effect: Tires lose tread depth and structural integrity, making them more vulnerable to punctures and blowouts.
	•	Signs: Bald or cracked tires, visible wear bars, skidding on wet roads.

5️⃣ Valve Stem Damage
	•	Effect: A faulty or broken valve stem allows air to escape.
	•	Signs: Slow loss of air without visible punctures, hissing sound near the valve.

6️⃣ Hitting Potholes or Curbs
	•	Effect: A hard impact can damage the tire’s sidewall, causing a blowout or air leak.
	•	Signs: A sudden flat after hitting an object, bulges on the tire sidewall.

7️⃣ Bead Leaks (Poor Seal Between Tire & Rim)
	•	Effect: Air escapes through a loose seal between the tire and rim.
	•	Signs: Slow air loss, particularly in cold weather, difficulty maintaining tire pressure.

Solutions:
1️⃣ Temporary Fix: Use a Spare Tire

✅ How to Fix:
	1.	Find a Safe Spot: Pull over on level ground away from traffic.
	2.	Use the Parking Brake: Prevents the car from moving.
	3.	Loosen the Lug Nuts: Before lifting the car with a jack.
	4.	Jack Up the Car: Place the jack at the correct lifting point.
	5.	Remove the Flat Tire & Install the Spare: Tighten the lug nuts in a star pattern.
	6.	Lower the Car & Check Tire Pressure.

🛠️ When to Seek Help? If the spare tire is also flat or you don’t have the necessary tools.

2️⃣ Fix Small Punctures with a Tire Repair Kit

✅ How to Fix:
	1.	Find the Puncture: Spray soapy water on the tire and look for bubbles.
	2.	Remove the Object (If Visible): Use pliers to pull out nails or screws.
	3.	Use a Tire Plug Kit:
	•	Insert the reaming tool into the hole to clean it.
	•	Push a rubber plug into the hole using the tool provided.
	4.	Inflate the Tire & Check for Leaks.

🛠️ When to Seek Help? If the hole is on the sidewall or larger than ¼ inch, the tire must be replaced.

3️⃣ Use a Tire Sealant (Quick Fix for Small Leaks)

✅ How to Fix:
	1.	Shake the Sealant Can Well.
	2.	Attach the Nozzle to the Valve Stem.
	3.	Release the Sealant into the Tire.
	4.	Drive Slowly for 5-10 Minutes to Spread the Sealant.

🛠️ When to Seek Help? If the tire deflates again after using sealant, the damage is too severe.

4️⃣ Check & Repair a Leaking Valve Stem

✅ How to Fix:
	1.	Apply Soapy Water to the Valve Stem. If bubbles form, air is leaking.
	2.	Tighten the Valve Stem Core with a Valve Tool.
	3.	If the Leak Persists, Replace the Valve Stem.

🛠️ When to Seek Help? If you’re not comfortable removing and installing a new valve stem.

5️⃣ Fix Bead Leaks (Leak Between Rim & Tire)

✅ How to Fix:
	1.	Remove the Tire from the Rim (If Necessary).
	2.	Clean the Bead Seat & Rim Edge.
	3.	Apply Bead Sealant & Reinflate the Tire.

🛠️ When to Seek Help? If the leak continues after resealing, the rim might be damaged.

🚨 What to Do If You Get a Flat Tire While Driving?

1️⃣ Do Not Slam the Brakes – Instead, ease off the accelerator.
2️⃣ Steer Straight & Gradually Slow Down.
3️⃣ Pull Over to a Safe Location.
4️⃣ Turn on Hazard Lights & Set Up Reflective Triangles.
5️⃣ Replace the Tire or Call for Roadside Assistance.

🚀 Preventive Maintenance Tips for Avoiding Flat Tires

✅ Check Tire Pressure Weekly – Use a tire pressure gauge.
✅ Avoid Driving Over Potholes or Sharp Objects.
✅ Rotate Tires Every 5,000 - 7,000 Miles.
✅ Replace Worn-Out Tires Before They Become a Risk.
✅ Inspect Tire Tread with the “Penny Test”:
	•	Insert a penny into the tread with Lincoln’s head down.
	•	If you can see all of Lincoln’s head, the tread is too worn.
✅ Carry a Spare Tire, Jack, and Tire Repair Kit in Your Car.

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ The puncture is larger than ¼ inch.
❌ The sidewall is damaged (never repair sidewall punctures).
❌ The tire won’t hold air even after patching.
❌ The rim is bent or cracked, causing air leaks.

''';

      case 'Electrical Problems':
        return '''
Common Symptoms:
1️⃣ Dead or Weak Battery
	•	Effect: The car won’t start or will struggle to turn over.
	•	Signs: Dim headlights, slow cranking engine, dashboard warning lights.

2️⃣ Faulty Alternator
	•	Effect: The battery won’t charge, leading to electrical failures.
	•	Signs: Battery warning light, flickering headlights, dead battery even after charging.

3️⃣ Blown Fuses
	•	Effect: Loss of power to specific components (radio, lights, windows).
	•	Signs: A single system not working while others function normally.

4️⃣ Faulty Wiring or Loose Connections
	•	Effect: Random electrical failures, flickering lights, warning messages.
	•	Signs: Burning smell, exposed wires, intermittent electrical failures.

5️⃣ Bad Ignition Switch
	•	Effect: The car won’t start or may shut off while driving.
	•	Signs: No response when turning the key, flickering dashboard lights.

6️⃣ Parasitic Battery Drain
	•	Effect: The battery drains overnight even when the car is off.
	•	Signs: Dead battery after the car sits for a while, electrical components staying on when they shouldn’t.

7️⃣ Bad Starter Motor
	•	Effect: The engine won’t crank or will make a clicking noise.
	•	Signs: No engine sound when turning the key, but the battery is fine.

8️⃣ Malfunctioning Sensors or ECU Issues
	•	Effect: Car misfires, stalls, or goes into limp mode.
	•	Signs: Check Engine Light (CEL), unusual acceleration behavior, error codes.

Solutions:
1️⃣ Test & Replace a Dead Battery

✅ How to Fix:
	1.	Check Battery Voltage with a Multimeter:
	•	A healthy battery should read 12.6V or more when off and 13.7V–14.7V when running.
	2.	Clean the Battery Terminals:
	•	Use a wire brush to remove corrosion.
	3.	Jump-Start the Car:
	•	If the engine starts, the battery may need recharging or replacement.
	4.	Replace the Battery if It’s Over 3-5 Years Old.

🛠️ When to Seek Help? If the battery keeps draining, you may have a parasitic drain issue.

2️⃣ Check & Replace a Bad Alternator

✅ How to Fix:
	1.	Test the Alternator Output with a Multimeter:
	•	Start the engine and measure battery voltage. If it’s below 13.5V, the alternator is faulty.
	2.	Check for a Loose or Worn Alternator Belt.
	3.	Replace the Alternator if It’s Not Charging the Battery.

🛠️ When to Seek Help? If the battery keeps dying even after replacing it.

3️⃣ Inspect & Replace Blown Fuses

✅ How to Fix:
	1.	Locate the Fuse Box (usually under the dashboard or hood).
	2.	Use the Fuse Diagram to Identify the Affected Circuit.
	3.	Check for a Blown Fuse (a broken wire inside).
	4.	Replace the Fuse with One of the Same Amp Rating.

🛠️ When to Seek Help? If the new fuse blows again, there may be a short circuit.

4️⃣ Diagnose & Fix Wiring Issues

✅ How to Fix:
	1.	Inspect the Wiring for Frays, Burns, or Loose Connections.
	2.	Use Electrical Tape or Heat Shrink Tubing to Cover Exposed Wires.
	3.	Secure Loose Ground Wires to Metal Parts of the Car.

🛠️ When to Seek Help? If you notice burning smells or suspect a short circuit.

5️⃣ Fix an Ignition Switch Problem

✅ How to Fix:
	1.	Check for Loose Ignition Wiring.
	2.	Test the Ignition Switch with a Multimeter.
	3.	If the Car Won’t Start, Try Wiggling the Key in the Ignition.
	4.	Replace the Ignition Switch if the Car Won’t Start.

🛠️ When to Seek Help? If the car dies randomly while driving.

6️⃣ Fix Parasitic Battery Drain

✅ How to Fix:
	1.	Use a Multimeter to Check for Battery Drain:
	•	Set it to amps mode and place the leads between the battery terminal and cable.
	•	A reading above 50mA indicates a drain.
	2.	Pull Out Fuses One by One to Find the Problem Circuit.
	3.	Fix or Replace the Faulty Component Causing the Drain.

🛠️ When to Seek Help? If you cannot identify the source of the drain.

7️⃣ Fix a Bad Starter Motor

✅ How to Fix:
	1.	Check if the Starter Clicks but Doesn’t Crank the Engine.
	2.	Tap the Starter with a Wrench (Temporary Fix).
	3.	Test the Starter Relay and Replace It If Needed.
	4.	Replace the Starter Motor if It’s Completely Dead.

🛠️ When to Seek Help? If the engine won’t turn over at all.

8️⃣ Fix Sensor or ECU Issues

✅ How to Fix:
	1.	Use an OBD-II Scanner to Read Error Codes.
	2.	Check & Clean Affected Sensors (Oxygen Sensor, MAF, Crankshaft Sensor).
	3.	Disconnect the Battery for 15 Minutes to Reset the ECU.
	4.	Update or Replace the ECU If the Problem Persists.

🛠️ When to Seek Help? If the car enters limp mode or won’t start due to ECU failure.

🚨 Signs You Need Immediate Electrical Repairs

⚠️ Burning smell from the dashboard or wires.
⚠️ Car won’t start even after replacing the battery.
⚠️ Headlights flicker or dim while driving.
⚠️ Electrical systems randomly turn off or reset.
⚠️ Repeated blown fuses.

🚀 Preventive Maintenance Tips for Avoiding Electrical Issues

✅ Check the Battery Every 6 Months.
✅ Tighten Battery Terminals & Clean Corrosion Regularly.
✅ Inspect Wiring Harnesses & Look for Damaged Wires.
✅ Replace Old Batteries Every 3-5 Years.
✅ Test the Alternator If You Notice Dim Headlights.
✅ Use a Surge Protector When Jump-Starting.
✅ Turn Off Electronics Before Shutting Off the Engine.

🔧 When to Visit a Mechanic?

Seek professional help if:
❌ The car won’t start even with a new battery.
❌ You experience random power losses while driving.
❌ The Check Engine Light (CEL) won’t turn off.
❌ You smell burning wires or see smoke.
❌ The starter clicks but won’t crank the engine.
''';

      case 'Warning Light':
        return '''
🔍 Common Causes of Warning Lights

1️⃣ Check Engine Light (CEL) 🚗

🔹 Causes:
	•	Loose or faulty gas cap (most common).
	•	Malfunctioning oxygen sensor.
	•	Bad mass airflow (MAF) sensor.
	•	Failing spark plugs or ignition coils.
	•	Catalytic converter issues.

🔹 Solution:
✅ Tighten or replace the gas cap – A loose cap can trigger the light.
✅ Use an OBD-II scanner to check fault codes.
✅ Clean or replace the oxygen sensor or MAF sensor if faulty.
✅ Replace spark plugs or ignition coils if misfiring.
✅ Inspect the catalytic converter for clogging or damage.

🛠 When to Visit a Mechanic? If the light flashes, it indicates a serious engine misfire that can damage the catalytic converter.

2️⃣ Battery Warning Light 🔋

🔹 Causes:
	•	Failing or weak battery.
	•	Faulty alternator (not charging the battery).
	•	Loose or corroded battery terminals.

🔹 Solution:
✅ Test battery voltage with a multimeter (should be 12.6V when off and 13.7V–14.7V when running).
✅ Check alternator output – If voltage drops below 13.5V, replace the alternator.
✅ Clean and tighten battery terminals to ensure a proper connection.

🛠 When to Visit a Mechanic? If the battery dies frequently, even after replacing it.

3️⃣ Oil Pressure Warning Light 🛢️

🔹 Causes:
	•	Low engine oil levels.
	•	Faulty oil pressure sensor.
	•	Clogged or dirty oil filter.
	•	Worn-out oil pump.

🔹 Solution:
✅ Check the engine oil level and top up if low.
✅ Replace the oil filter if clogged.
✅ If the issue persists, test the oil pressure sensor and replace it if necessary.
✅ If low oil pressure continues, have a mechanic inspect the oil pump.

🛠 When to Visit a Mechanic? If the light remains on even after adding oil, it may indicate a failing oil pump.

4️⃣ Brake Warning Light 🚦

🔹 Causes:
	•	Low brake fluid.
	•	Worn-out brake pads.
	•	Handbrake (parking brake) is engaged.
	•	Faulty brake sensor.

🔹 Solution:
✅ Check brake fluid levels and refill if low.
✅ Inspect brake pads – If they are thin, replace them immediately.
✅ Ensure the parking brake is fully released.
✅ Check brake sensors and replace them if faulty.

🛠 When to Visit a Mechanic? If brakes feel soft or unresponsive, get them inspected immediately.

5️⃣ Temperature Warning Light 🌡️

🔹 Causes:
	•	Low coolant levels.
	•	Malfunctioning radiator fan.
	•	Thermostat failure.
	•	Leaking or clogged radiator.

🔹 Solution:
✅ Turn off the AC and let the engine cool.
✅ Check and refill coolant (if low).
✅ Inspect radiator hoses for leaks.
✅ If overheating continues, replace the thermostat.

🛠 When to Visit a Mechanic? If the engine continues to overheat, stop driving immediately to avoid severe engine damage.

6️⃣ ABS Warning Light 🚗💨

🔹 Causes:
	•	Faulty ABS sensors.
	•	Low brake fluid.
	•	Malfunctioning ABS module.

🔹 Solution:
✅ Check brake fluid levels and refill if needed.
✅ Inspect and clean ABS sensors (located near each wheel).
✅ Use an OBD-II scanner to diagnose the ABS system.

🛠 When to Visit a Mechanic? If the ABS system fails completely, the vehicle may skid under hard braking.

7️⃣ Airbag Warning Light 🎈

🔹 Causes:
	•	Faulty airbag sensor.
	•	Disconnected or damaged airbag wiring.
	•	Previous airbag deployment not reset.

🔹 Solution:
✅ Check for loose airbag wiring under seats.
✅ Use an OBD-II scanner to reset the airbag system.
✅ If the airbag was deployed, visit a mechanic to reset or replace it.

🛠 When to Visit a Mechanic? If the light stays on, airbags may not deploy in an accident.

8️⃣ Tire Pressure Warning Light (TPMS) ⚠️

🔹 Causes:
	•	Low tire pressure.
	•	Faulty TPMS sensor.
	•	Recent tire replacement without sensor reset.

🔹 Solution:
✅ Check tire pressure and inflate to recommended levels.
✅ Reset the TPMS system (refer to the owner’s manual).
✅ Replace faulty TPMS sensors if necessary.

🛠 When to Visit a Mechanic? If the TPMS warning persists even after inflating the tires correctly.

9️⃣ Fuel System Warning Light ⛽

🔹 Causes:
	•	Clogged fuel filter.
	•	Failing fuel pump.
	•	Contaminated fuel.

🔹 Solution:
✅ Refill the tank with clean fuel (avoid low-quality gas).
✅ Replace the fuel filter if clogged.
✅ Have a mechanic check the fuel pump if the engine struggles to start.

🛠 When to Visit a Mechanic? If the car hesitates, stalls, or struggles to accelerate.

🚀 How to Diagnose a Warning Light?

1️⃣ Step: Use an OBD-II Scanner 📡
	•	Plug it into the diagnostic port (under the dashboard).
	•	Read the error code to identify the issue.

2️⃣ Step: Refer to the Owner’s Manual 📖
	•	Each warning light has a specific meaning depending on the car model.

3️⃣ Step: Check for Obvious Issues 🔍
	•	Look for leaks, loose wires, low fluids, or unusual sounds.

4️⃣ Step: Reset the Warning Light
	•	Some lights turn off after fixing the problem and driving for a while.
	•	If it stays on, manual reset may be required using an OBD-II scanner.
	
	🛑 When to Stop Driving & Call for Help?

❌ Flashing Check Engine Light (severe misfire risk).
❌ Overheating Light Stays On (engine damage risk).
❌ Brake or ABS Warning Light with Soft Brakes.
❌ Battery Light with Sudden Power Loss.

🚗 If unsure, it’s best to stop driving and get the car inspected immediately.

🔧 Preventive Maintenance to Avoid Warning Lights

✅ Regularly check fluids (oil, coolant, brake, transmission).
✅ Inspect tires and keep them properly inflated.
✅ Get routine brake and battery checks.
✅ Use high-quality fuel and replace filters as needed.
✅ Scan for trouble codes even if no light appears.

🔹 A solid warning light means a problem that needs checking.
🔹 A flashing warning light signals an urgent issue.
🔹 Use an OBD-II scanner to diagnose codes.
🔹 Fix minor issues yourself (loose gas cap, low fluids).
🔹 For major problems, visit a mechanic ASAP.
''';

      case 'Fuel System Issues':
        return '''
Common Symptoms:

1️⃣ Clogged Fuel Filter – Prevents fuel from flowing smoothly to the engine.
2️⃣ Bad Fuel Pump – Fails to supply the required fuel pressure.
3️⃣ Dirty or Faulty Fuel Injectors – Causes engine misfires and poor performance.
4️⃣ Contaminated Fuel – Water or dirt in the fuel can damage the system.
5️⃣ Fuel Pressure Regulator Failure – Leads to incorrect fuel-air mixture.
6️⃣ Leaking Fuel Lines – Can cause fuel loss, reducing efficiency.
7️⃣ Faulty Mass Air Flow (MAF) Sensor – Affects the air-fuel ratio.

Solutions:
1️⃣ Clogged Fuel Filter

🔹 Symptoms: Engine sputtering, difficulty starting, power loss.
✅ Solution:
	•	Replace the fuel filter every 20,000–30,000 miles or as per the manual.
	•	If clogged, replace immediately to restore proper fuel flow.
	
2️⃣ Failing Fuel Pump

🔹 Symptoms: Difficulty starting, loss of power under load, whining noise from the fuel tank.
✅ Solution:
	•	Check for low fuel pressure using a fuel pressure gauge.
	•	If low, replace the fuel pump (typically located inside the fuel tank).
	•	Avoid running the car on an empty tank, as it can overheat the pump.
	
3️⃣ Dirty or Faulty Fuel Injectors

🔹 Symptoms: Engine misfires, rough idling, poor acceleration.
✅ Solution:
	•	Use a fuel injector cleaner additive in the gas tank.
	•	If severe, remove and clean injectors manually or replace them.
	
4️⃣ Contaminated Fuel

🔹 Symptoms: Stalling, rough idling, decreased fuel efficiency.
✅ Solution:
	•	Drain the contaminated fuel and refill with high-quality fuel.
	•	If water contamination is suspected, add fuel system cleaner or ethanol-based fuel additives.
	
5️⃣ Faulty Fuel Pressure Regulator

🔹 Symptoms: Black smoke from exhaust, poor fuel economy.
✅ Solution:
	•	Check fuel pressure with a gauge; if too high or too low, replace the fuel pressure regulator.
	
6️⃣ Leaking Fuel Lines

🔹 Symptoms: Strong fuel smell, visible fuel leaks under the car.
✅ Solution:
	•	Inspect for cracks or loose connections.
	•	Replace damaged fuel lines immediately to prevent safety hazards.

7️⃣ Faulty Mass Air Flow (MAF) Sensor

🔹 Symptoms: Poor acceleration, rough idling, stalling.
✅ Solution:
	•	Clean the MAF sensor using specialized MAF cleaner spray.
	•	If faulty, replace the sensor to restore correct air-fuel ratio.
	
🚗 Preventive Measures

✅ Use high-quality fuel to prevent contamination.
✅ Replace the fuel filter regularly.
✅ Keep the fuel tank above ¼ full to avoid pump damage.
✅ Use fuel system cleaners every few thousand miles.

🚨 If issues persist, have a mechanic inspect the fuel system for hidden faults.						
''';

      case 'Air Conditioning Failures':
        return '''
Common Symptoms:
  1.	Low Refrigerant Levels
	•	The refrigerant may leak or get low over time, which reduces the system’s ability to cool effectively.
	2.	Clogged Condenser
	•	Dirt, leaves, or other debris can block the condenser, preventing heat dissipation and leading to poor cooling performance.
	3.	Faulty Compressor
	•	The compressor is responsible for circulating refrigerant. If it fails, the entire system will not function properly.
	4.	Blown Fuse or Electrical Issues
	•	A blown fuse, faulty wiring, or other electrical issues can prevent essential components, like the compressor or blower fan, from operating.
	5.	Faulty Thermostat
	•	If the thermostat is malfunctioning, the air conditioner may not turn on, or it could run too frequently or too infrequently.
	6.	Clogged or Frozen Evaporator Coils
	•	Evaporator coils can become clogged with dirt or freeze up due to low refrigerant, which prevents the system from cooling effectively.
	7.	Faulty Blower Motor
	•	A defective blower motor can lead to weak or no airflow, affecting the cooling process inside the cabin.
	8.	Clogged Air Filters
	•	Dirty or clogged air filters can restrict airflow, reducing the system’s cooling capacity.
	9.	Incorrectly Set Temperature Controls
	•	Incorrect temperature or mode settings can cause the AC to fail to cool effectively.
	10.	Poor Airflow Due to Blocked Vents

	•	Blocked air vents or ducts can restrict airflow, making the system inefficient.

	11.	Refrigerant Contamination

	•	Contaminants, such as air or moisture, can mix with refrigerant, reducing its efficiency and causing the system to fail.

Solutions:
  1.	Low Refrigerant Levels
	•	Solution: A professional technician should check for leaks, repair any found, and recharge the system with the correct refrigerant.
	2.	Clogged Condenser
	•	Solution: Clean the condenser by removing dirt, leaves, and other debris. Use a soft brush or coil cleaner for better results.
	3.	Faulty Compressor
	•	Solution: Inspect the compressor for electrical or mechanical faults. If damaged, it will need to be repaired or replaced by a professional.
	4.	Blown Fuse or Electrical Issues
	•	Solution: Replace any blown fuses and inspect the wiring. If electrical faults persist, a technician should be consulted to check the system’s wiring and connections.
	5.	Faulty Thermostat
	•	Solution: Calibrate or replace the thermostat if it is malfunctioning. A malfunctioning thermostat can cause improper temperature regulation.
	6.	Clogged or Frozen Evaporator Coils
	•	Solution: Clean the evaporator coils to remove dirt buildup. If frozen, turn off the AC and allow the coils to thaw. Check for low refrigerant and refill as necessary.
	7.	Faulty Blower Motor
	•	Solution: Inspect the blower motor for issues. Clean the motor and any dust or debris. If it is damaged, it may need to be replaced.
	8.	Clogged Air Filters
	•	Solution: Replace or clean air filters regularly to maintain proper airflow. Check filters every 1-3 months and replace them as necessary.
	9.	Incorrectly Set Temperature Controls
	•	Solution: Ensure the temperature and mode are correctly set to “cool” and adjust the temperature to a lower value. Reset the system if necessary.
	10.	Poor Airflow Due to Blocked Vents

	•	Solution: Inspect and clean the air vents and ducts. Remove any obstructions and adjust the direction of the vents for optimal airflow.

	11.	Refrigerant Contamination

	•	Solution: Have a professional evacuate contaminated refrigerant and flush the system to remove contaminants. Then refill the system with clean refrigerant.
''';

      case 'Fluid Leaks':
        return '''
Common Causes of Fluids Leaks:
  1.	Worn or Damaged Seals and Gaskets
	•	Over time, seals and gaskets can degrade, leading to leaks in the engine, transmission, or cooling system.
	2.	Cracked or Corroded Hoses
	•	Rubber hoses can crack due to age, heat, or exposure to chemicals, causing fluid leaks in the coolant, brake, or power steering systems.
	3.	Loose or Damaged Fittings
	•	Loose or improperly installed fittings in the fuel system, transmission, or cooling system can lead to fluid leaks.
	4.	Failed Oil Pan or Transmission Pan Gasket
	•	The gaskets on the oil pan or transmission pan can fail due to wear, causing oil or transmission fluid leaks.
	5.	Leaking Fuel Lines
	•	Fuel lines can crack or become loose, causing fuel to leak, which is a serious safety hazard.
	6.	Faulty or Worn Radiator
	•	A damaged radiator can cause coolant to leak, often due to physical damage or corrosion.
	7.	Overfilled Fluids
	•	If the fluid level is too high (e.g., engine oil or transmission fluid), it can cause pressure to build up and result in leaks.
	8.	Cracked Engine Block or Cylinder Head
	•	A crack in the engine block or cylinder head can cause oil or coolant to leak, often due to overheating or manufacturing defects.
	9.	Damaged Transmission Cooler Lines
	•	These lines carry fluid to and from the transmission cooler. If they become damaged, they can cause fluid to leak.
	10.	Faulty Brake Lines
  •	Rust or damage to brake lines can cause brake fluid to leak, compromising braking performance.

Solutions:
  1.	Worn or Damaged Seals and Gaskets
	•	Over time, seals and gaskets can degrade, leading to leaks in the engine, transmission, or cooling system.
	2.	Cracked or Corroded Hoses
	•	Rubber hoses can crack due to age, heat, or exposure to chemicals, causing fluid leaks in the coolant, brake, or power steering systems.
	3.	Loose or Damaged Fittings
	•	Loose or improperly installed fittings in the fuel system, transmission, or cooling system can lead to fluid leaks.
	4.	Failed Oil Pan or Transmission Pan Gasket
	•	The gaskets on the oil pan or transmission pan can fail due to wear, causing oil or transmission fluid leaks.
	5.	Leaking Fuel Lines
	•	Fuel lines can crack or become loose, causing fuel to leak, which is a serious safety hazard.
	6.	Faulty or Worn Radiator
	•	A damaged radiator can cause coolant to leak, often due to physical damage or corrosion.
	7.	Overfilled Fluids
	•	If the fluid level is too high (e.g., engine oil or transmission fluid), it can cause pressure to build up and result in leaks.
	8.	Cracked Engine Block or Cylinder Head
	•	A crack in the engine block or cylinder head can cause oil or coolant to leak, often due to overheating or manufacturing defects.
	9.	Damaged Transmission Cooler Lines
	•	These lines carry fluid to and from the transmission cooler. If they become damaged, they can cause fluid to leak.
	10.	Faulty Brake Lines
	•	Rust or damage to brake lines can cause brake fluid to leak, compromising braking performance.
''';

      case 'Suspension Issues':
        return '''
Common Symptoms:
	1.	Worn-Out Shock Absorbers or Struts
	•	Shock absorbers or struts are responsible for controlling the movement of the vehicle’s springs. Over time, they can wear out, leading to poor ride quality and handling.
	2.	Broken or Damaged Springs
	•	Coil or leaf springs support the vehicle’s weight and provide stability. If a spring breaks or becomes damaged, it can cause uneven ride height or affect the vehicle’s stability.
	3.	Worn Ball Joints
	•	Ball joints are critical for the steering and suspension system. Worn-out ball joints can lead to excessive play in the steering, causing instability and handling issues.
	4.	Damaged Control Arm Bushings
	•	The control arm connects the suspension to the vehicle’s frame. If the bushings that cushion the control arm wear out, it can result in noisy suspension and poor handling.
	5.	Faulty Tie Rods
	•	Tie rods connect the steering mechanism to the wheels. A worn or damaged tie rod can cause steering problems and reduce overall control of the vehicle.
	6.	Misaligned Wheels
	•	Wheel alignment issues can lead to suspension problems, causing uneven tire wear, pulling to one side, or poor handling.
	7.	Leaking Suspension Components
	•	Leaks in parts such as the shock absorbers, struts, or air suspension system can cause the suspension to lose its ability to properly absorb impacts, leading to poor ride quality.
	8.	Worn-Out Bushings
	•	Bushings are used throughout the suspension system to reduce friction and absorb shocks. Worn-out bushings can cause the suspension to feel loose and unresponsive.
	9.	Damaged Sway Bar or Sway Bar Links
	•	The sway bar stabilizes the vehicle during turns. A damaged sway bar or its links can cause the vehicle to sway excessively, leading to poor handling.
	10.	Excessive Weight Load
	•	Overloading the vehicle can stress the suspension system, causing damage to springs, shocks, or struts, and leading to suspension issues.

Solutions:
	1.	Worn or Leaking Shocks/Struts
	•	Solution: Replace worn-out or leaking shocks and struts. This usually involves removing the old components and installing new ones that match the vehicle’s specifications. Make sure to inspect the system for any other signs of wear.
	2.	Broken or Weak Springs
	•	Solution: Inspect the springs for signs of damage or weakness. Replace any broken or damaged springs with new ones designed for your vehicle’s make and model. For weakened springs, upgrading to a stronger spring may be necessary.
	3.	Worn-Out Bushings
	•	Solution: Examine the suspension system for worn-out bushings. These can be replaced by removing the old bushings and installing new ones. This helps restore proper alignment and handling.
	4.	Faulty Ball Joints
	•	Solution: If the ball joints are worn, they should be replaced. This typically involves removing the control arm or steering knuckle to access the ball joints and replacing them with new ones.
	5.	Damaged Control Arms
	•	Solution: Inspect the control arms for damage or bending. If damaged, the control arm should be replaced to ensure the suspension and alignment are functioning properly.
	6.	Misaligned Wheels
	•	Solution: Take the vehicle to a professional for wheel alignment. This will correct the angles of the wheels to ensure they’re aligned properly, which improves handling and tire wear.
	7.	Leaking or Damaged Power Steering System
	•	Solution: If there’s a leak or damage in the power steering system, the leak must be repaired, and the power steering fluid topped up. If there’s severe damage to the system, it may need a replacement part, such as a pump or steering rack.
	8.	Damaged or Broken Sway Bar Links
	•	Solution: If the sway bar links are damaged or broken, they need to be replaced. After replacing the links, ensure the sway bar is intact and functioning as intended to stabilize the vehicle during turns.
	9.	Excessive Load
	•	Solution: Remove excess weight from the vehicle to prevent undue strain on the suspension. Make sure that the vehicle is not exceeding its maximum load capacity.
	10.	Misuse of Suspension Components
	•	Solution: Drive carefully, avoiding harsh driving conditions or rough terrain if possible. Regularly inspect the suspension system for damage and replace worn components as needed to prolong the life of the suspension.
By addressing these suspension issues promptly and correctly, you can ensure a smoother, safer ride and avoid more expensive repairs down the line. Regular maintenance, including inspections and timely replacements of worn parts, is key to extending the life of your vehicle’s suspension system.
''';

      case 'Leaking Radiators':
        return '''
Common Symptoms:
	1.	Corrosion and Rust
	•	Over time, radiators can corrode due to constant exposure to coolant and metal reactions, leading to leaks.
	2.	Damaged or Cracked Radiator Core
	•	Physical damage from debris, accidents, or excessive pressure can cause cracks in the radiator, resulting in leaks.
	3.	Worn or Loose Radiator Hoses
	•	Hoses connecting the radiator to the engine can degrade, crack, or loosen, leading to coolant leaks.
	4.	Faulty Radiator Cap
	•	A damaged or loose radiator cap can fail to maintain proper pressure, causing coolant to leak from the overflow tank.
	5.	Leaking or Failing Water Pump
	•	A worn-out or damaged water pump can leak coolant, which may appear as a radiator leak.
	6.	Damaged or Worn-Out Radiator Seals
	•	Seals and gaskets within the radiator can deteriorate over time, leading to leaks at the seams.
	7.	Overheating Issues
	•	Extreme overheating can cause the radiator to expand and crack, leading to coolant leaks.
	8.	Improper Coolant Mixture
	•	Using the wrong coolant or an improper water-to-coolant ratio can cause internal corrosion and lead to leaks.
	9.	Clogged Radiator
	•	Blockages in the radiator can increase internal pressure, which can lead to leaks in weaker areas.
	10.	Manufacturing Defects or Poor Installation
	•	Some radiators may have factory defects, or improper installation can lead to stress points where leaks develop.
Solutions:
	1.	Corrosion and Rust
	•	Solution: Inspect the radiator for rust or corrosion. If minor, use a radiator flush to clean it. If heavily corroded, replace the radiator to prevent future leaks.
	2.	Damaged or Cracked Radiator Core
	•	Solution: Small cracks may be temporarily sealed with a high-quality radiator sealant. However, for large cracks, the radiator should be replaced.
	3.	Worn or Loose Radiator Hoses
	•	Solution: Inspect all radiator hoses for cracks, leaks, or looseness. Replace damaged hoses and ensure all hose clamps are securely tightened.
	4.	Faulty Radiator Cap
	•	Solution: Test the radiator cap’s pressure-holding capability. If it’s faulty or doesn’t fit properly, replace it with a new one of the correct pressure rating.
	5.	Leaking or Failing Water Pump
	•	Solution: Check for leaks around the water pump. If the pump is leaking, it should be replaced, and the coolant system should be refilled and properly bled.
	6.	Damaged or Worn-Out Radiator Seals
	•	Solution: If seals or gaskets are leaking, they should be replaced. In some cases, a radiator sealant may temporarily stop minor leaks.
	7.	Overheating Issues
	•	Solution: Identify the cause of overheating, such as a stuck thermostat or low coolant levels. Repair the underlying issue and ensure the cooling system functions properly.
	8.	Improper Coolant Mixture
	•	Solution: Drain the coolant and refill it with the manufacturer-recommended coolant type and correct water-to-coolant ratio to prevent internal corrosion.
	9.	Clogged Radiator
	•	Solution: Flush the radiator using a radiator flush solution to remove blockages. If the clog is severe, professional cleaning or radiator replacement may be necessary.
	10.	Manufacturing Defects or Poor Installation
	•	Solution: If the radiator was recently replaced or installed incorrectly, ensure it is mounted properly. If it has a factory defect, replacing it under warranty is recommended.
	''';

      case 'Brake':
        return '''
Common Symptoms:
  1.	Worn Brake Pads
	•	Brake pads wear down over time due to friction, reducing braking efficiency and causing squealing or grinding noises.
	2.	Leaking Brake Fluid
	•	A leak in the brake lines, master cylinder, or calipers can cause a loss of hydraulic pressure, leading to poor braking performance.
	3.	Warped Brake Rotors
	•	Excessive heat from braking can cause rotors to warp, leading to vibrations or pulsations in the brake pedal.
	4.	Air in Brake Lines
	•	Air bubbles in the brake system reduce hydraulic pressure, making the brake pedal feel spongy and reducing stopping power.
	5.	Faulty Brake Master Cylinder
	•	A failing master cylinder can result in an inconsistent or soft brake pedal, leading to braking failure.
	6.	Seized or Sticking Brake Calipers
	•	Corrosion or dirt buildup can cause the calipers to stick, leading to uneven braking or dragging brakes.
	7.	Overheated or Glazed Brake Pads
	•	Excessive braking, such as driving downhill for long periods, can overheat and glaze brake pads, reducing their effectiveness.
	8.	Worn or Damaged Brake Lines
	•	Rubber brake lines can crack or leak over time, leading to a loss of brake fluid and reduced braking efficiency.
	9.	ABS (Anti-lock Braking System) Malfunction
	•	Faulty ABS sensors or control modules can lead to unpredictable braking performance or ABS warning lights on the dashboard.
	10.	Contaminated Brake Fluid
	•	Old or contaminated brake fluid absorbs moisture, reducing braking performance and potentially damaging brake components.
Solutions:
	1.	Worn Brake Pads
	•	Solution: Replace worn brake pads with new ones before they wear down completely to prevent rotor damage.
	2.	Leaking Brake Fluid
	•	Solution: Identify and repair leaks in the brake system by replacing damaged brake lines, master cylinders, or caliper seals. Refill and bleed the system with fresh brake fluid.
	3.	Warped Brake Rotors
	•	Solution: Resurface or replace warped rotors to restore smooth braking performance.
	4.	Air in Brake Lines
	•	Solution: Bleed the brake system to remove air bubbles and restore proper hydraulic pressure.
	5.	Faulty Brake Master Cylinder
	•	Solution: Inspect and replace the master cylinder if it is leaking or failing to maintain pressure.
	6.	Seized or Sticking Brake Calipers
	•	Solution: Clean or replace stuck brake calipers and ensure that caliper slides are properly lubricated.
	7.	Overheated or Glazed Brake Pads
	•	Solution: Replace overheated or glazed brake pads and avoid excessive braking by downshifting when driving downhill.
	8.	Worn or Damaged Brake Lines
	•	Solution: Inspect and replace cracked or leaking brake lines to maintain proper brake fluid pressure.
	9.	ABS (Anti-lock Braking System) Malfunction
	•	Solution: Scan the ABS system for error codes and replace faulty sensors, wiring, or the ABS control module as needed.
	10.	Contaminated Brake Fluid
	•	Solution: Flush the brake fluid and refill with fresh fluid according to the manufacturer’s specifications.
	
	''';

      case 'Shaking Steering Wheel':
        return '''
Common Symptoms:
 	1.	Unbalanced Tires
	•	Uneven weight distribution in tires can cause vibrations, especially at higher speeds.
	2.	Warped Brake Rotors
	•	If the steering wheel shakes when braking, it may be due to warped or uneven brake rotors.
	3.	Worn or Loose Suspension Components
	•	Components like ball joints, tie rods, or control arm bushings can wear out or loosen, leading to instability and vibrations.
	4.	Misaligned Wheels
	•	Improper wheel alignment can cause the steering wheel to shake and result in uneven tire wear.
	5.	Damaged or Bent Wheels
	•	Hitting potholes, curbs, or other road hazards can bend the wheels, leading to steering wheel vibrations.
	6.	Faulty Wheel Bearings
	•	Worn or damaged wheel bearings can cause the wheels to wobble, leading to shaking in the steering wheel.
	7.	Tire Issues (Uneven Wear or Damage)
	•	Tires with uneven wear patterns, bulges, or low tread depth can create vibrations when driving.
	8.	Failing Steering Components
	•	Worn steering rack mounts or power steering system issues can cause the steering wheel to shake.
	9.	Brake Caliper Issues
	•	If a brake caliper is sticking, it can cause the wheel to shake, especially when braking or at high speeds.
	10.	Axle Damage
	•	A bent or damaged axle, often caused by accidents or hitting a hard object, can cause the steering wheel to shake during acceleration.
	
	Solutions:
	1.	Unbalanced Tires
	•	Solution: Have the tires balanced at a tire shop to evenly distribute weight and eliminate vibrations.
	2.	Warped Brake Rotors
	•	Solution: Resurface or replace warped rotors to ensure smooth braking performance.
	3.	Worn or Loose Suspension Components
	•	Solution: Inspect and replace worn ball joints, tie rods, or control arm bushings to restore stability.
	4.	Misaligned Wheels
	•	Solution: Get a professional wheel alignment to correct the angles of the tires and improve handling.
	5.	Damaged or Bent Wheels
	•	Solution: Inspect for bent or damaged wheels and replace them if necessary.
	6.	Faulty Wheel Bearings
	•	Solution: Check for worn or damaged wheel bearings and replace them to prevent wheel wobbling.
	7.	Tire Issues (Uneven Wear or Damage)
	•	Solution: Rotate tires regularly and replace damaged or excessively worn tires.
	8.	Failing Steering Components
	•	Solution: Inspect the steering rack and power steering system for issues and replace faulty components.
	9.	Brake Caliper Issues
	•	Solution: Check for sticking brake calipers and clean, lubricate, or replace them as needed.
	10.	Axle Damage
	•	Solution: Inspect the axle for bends or damage and replace it if necessary to eliminate vibrations.
	''';

      case 'Malfunctioning Sensors':
        return '''
Common Symptoms:
  1.	Dirt and Debris Buildup
	•	Sensors can become contaminated with dirt, dust, or grease, leading to inaccurate readings or failure.
	2.	Wiring Issues (Loose or Damaged Wires)
	•	Frayed, corroded, or disconnected wires can prevent signals from reaching the vehicle’s computer.
	3.	Faulty Sensor Components
	•	Internal sensor components may degrade over time due to wear and tear, causing erratic readings.
	4.	Moisture or Water Damage
	•	Water exposure can corrode sensor connectors and lead to short circuits or incorrect sensor readings.
	5.	Software or ECU (Engine Control Unit) Issues
	•	A malfunctioning ECU or outdated software may misinterpret sensor signals, causing false warnings.
	6.	Sensor Misalignment or Improper Installation
	•	If a sensor is installed incorrectly or knocked out of place, it may not function as intended.
	7.	Electrical Interference
	•	Other electronic components or poor grounding can cause interference, leading to sensor errors.
	8.	Aging or Worn-Out Sensors
	•	Over time, sensors naturally degrade and may fail due to prolonged exposure to heat, vibration, and contaminants.
	9.	Battery or Voltage Irregularities
	•	Low or fluctuating voltage can affect sensor performance, leading to inconsistent readings.
	10.	Use of Low-Quality or Non-OEM Sensors
	•	Cheap or aftermarket sensors may not be properly calibrated for the vehicle, leading to inaccurate readings.
	
	Solutions:
	1.	Dirt and Debris Buildup
	•	Solution: Clean the affected sensors using an appropriate cleaning agent (e.g., MAF sensor cleaner, brake cleaner) to restore functionality.
	2.	Wiring Issues (Loose or Damaged Wires)
	•	Solution: Inspect sensor wiring for signs of fraying, corrosion, or disconnection and repair or replace as needed.
	3.	Faulty Sensor Components
	•	Solution: Test the sensor using a multimeter or scan tool; if it is defective, replace it with a new, OEM-quality sensor.
	4.	Moisture or Water Damage
	•	Solution: Dry out moisture-affected sensors, seal exposed connectors, and apply dielectric grease to prevent future water ingress.
	5.	Software or ECU (Engine Control Unit) Issues
	•	Solution: Reset or update the ECU software using a diagnostic tool to ensure accurate sensor communication.
	6.	Sensor Misalignment or Improper Installation
	•	Solution: Reinstall the sensor correctly or adjust its position as per the manufacturer’s specifications.
	7.	Electrical Interference
	•	Solution: Check grounding connections and reduce interference by using shielded wiring where necessary.
	8.	Aging or Worn-Out Sensors
	•	Solution: Replace sensors that have exceeded their lifespan or show signs of consistent malfunction.
	9.	Battery or Voltage Irregularities
	•	Solution: Test and replace a weak or faulty battery and ensure the alternator is supplying stable voltage.
	10.	Use of Low-Quality or Non-OEM Sensors
	•	Solution: Always use high-quality or OEM sensors designed for your specific vehicle model to ensure compatibility and accuracy.
	''';
      default:
        return 'No solution available at the moment.';
    }
  }
}